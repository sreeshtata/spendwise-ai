@echo off
setlocal enabledelayedexpansion
title SpendWise AI - Push to GitHub Repository

echo ======================================================================
echo          SpendWise AI - Upload to GitHub Repository
echo ======================================================================
echo Target Repo: https://github.com/sreeshtata/spendwise-ai
echo.

:: 1. Locate Git executable
where git >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [INFO] Git found in system PATH.
    goto :GIT_FOUND
)

:: Check common Git installation directories on Windows
if exist "%ProgramFiles%\Git\cmd\git.exe" (
    set "PATH=%ProgramFiles%\Git\cmd;!PATH!"
    echo [INFO] Found Git at %ProgramFiles%\Git\cmd
    goto :GIT_FOUND
)

if exist "%ProgramFiles(x86)%\Git\cmd\git.exe" (
    set "PATH=%ProgramFiles(x86)%\Git\cmd;!PATH!"
    echo [INFO] Found Git at %ProgramFiles(x86)%\Git\cmd
    goto :GIT_FOUND
)

if exist "%LocalAppData%\Programs\Git\cmd\git.exe" (
    set "PATH=%LocalAppData%\Programs\Git\cmd;!PATH!"
    echo [INFO] Found Git at %LocalAppData%\Programs\Git\cmd
    goto :GIT_FOUND
)

if exist "C:\Program Files\Git\bin\git.exe" (
    set "PATH=C:\Program Files\Git\bin;!PATH!"
    echo [INFO] Found Git at C:\Program Files\Git\bin
    goto :GIT_FOUND
)

:: Git is not installed
echo [ERROR] Git is not installed or could not be found on this computer.
echo.
echo Please install Git to upload your project to GitHub:
echo   1. Download and install Git from: https://git-scm.com/download/win
echo   2. Or install GitHub Desktop from: https://desktop.github.com/
echo   3. After installing, run this push_to_github.bat file again.
echo.
pause
exit /b 1

:GIT_FOUND
echo.
echo [1/5] Checking Git configuration...

:: Verify Git user.name and user.email are configured to prevent commit errors
for /f "tokens=*" %%g in ('git config user.name 2^>nul') do set GIT_USER=%%g
for /f "tokens=*" %%g in ('git config user.email 2^>nul') do set GIT_EMAIL=%%g

if "%GIT_USER%"=="" (
    echo [NOTICE] Git user.name not set. Configuring default: %USERNAME%
    git config user.name "%USERNAME%"
)

if "%GIT_EMAIL%"=="" (
    echo [NOTICE] Git user.email not set. Configuring default: %USERNAME%@spendwise.local
    git config user.email "%USERNAME%@spendwise.local"
)

echo.
echo [2/5] Initializing local repository...
if not exist ".git" (
    git init
    echo [INFO] Initialized empty Git repository.
) else (
    echo [INFO] Existing Git repository detected.
)

:: Switch/rename default branch to main
git branch -M main

echo.
echo [3/5] Configuring remote repository...
set REPO_URL=https://github.com/sreeshtata/spendwise-ai.git

git remote get-url origin >nul 2>&1
if %ERRORLEVEL% equ 0 (
    git remote set-url origin %REPO_URL%
    echo [INFO] Updated existing remote 'origin' to %REPO_URL%
) else (
    git remote add origin %REPO_URL%
    echo [INFO] Added remote 'origin' pointing to %REPO_URL%
)

echo.
echo [4/5] Staging and committing files...
:: Add all files respecting .gitignore
git add -A

:: Check if there are changes to commit
git status --porcelain > "%TEMP%\spendwise_git_status.txt" 2>&1
for %%R in ("%TEMP%\spendwise_git_status.txt") do set STATUS_SIZE=%%~zR

if %STATUS_SIZE% gtr 0 (
    git commit -m "feat: complete SpendWise AI Smart Spending Assistant with tests, PayPal sandbox, and docs"
    echo [INFO] Created commit with updated files.
) else (
    echo [INFO] No new changes to commit. Proceeding to push.
)
if exist "%TEMP%\spendwise_git_status.txt" del "%TEMP%\spendwise_git_status.txt"

echo.
echo [5/5] Pushing to GitHub (main branch)...
echo Note: If prompted, sign in via GitHub browser or enter your GitHub Personal Access Token (PAT).
echo.

git push -u origin main
if %ERRORLEVEL% equ 0 (
    goto :SUCCESS
)

echo.
echo [WARNING] Standard push failed. This usually happens if the remote repository
echo already contains files (such as a README or LICENSE created on GitHub).
echo.
set /p FORCE_CHOICE="Would you like to force push and overwrite remote with this project? (y/n): "
if /i "%FORCE_CHOICE%"=="y" (
    echo [INFO] Force pushing to origin main...
    git push -u origin main --force
    if !ERRORLEVEL! equ 0 (
        goto :SUCCESS
    ) else (
        echo [ERROR] Force push failed. Please check your GitHub permissions or credentials.
    )
) else (
    echo [INFO] Attempting to pull and rebase before pushing...
    git pull origin main --rebase
    git push -u origin main
    if !ERRORLEVEL! equ 0 (
        goto :SUCCESS
    ) else (
        echo [ERROR] Rebase and push failed. Please resolve conflicts or verify permissions.
    )
)

echo.
echo [ERROR] Push could not be completed.
echo Please verify:
echo   1. The repository https://github.com/sreeshtata/spendwise-ai exists.
echo   2. You have write/push access to the repository.
echo   3. Your GitHub credentials or Personal Access Token (PAT) are valid.
echo.
pause
exit /b 1

:SUCCESS
echo.
echo ======================================================================
echo [SUCCESS] Project successfully uploaded to GitHub!
echo Repository URL: https://github.com/sreeshtata/spendwise-ai
echo ======================================================================
echo.
pause
exit /b 0
